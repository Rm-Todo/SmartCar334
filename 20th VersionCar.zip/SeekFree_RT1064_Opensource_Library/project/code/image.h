#ifndef _IMAGE_H_
#define _IMAGE_H_
#include "zf_common_headfile.h"
//===================================================ȫ�ֱ�������===================================================
                            
    
     
extern int a,b,c;
extern uint8_t image[IMAGE_H][IMAGE_W];
extern int Rline[IMAGE_H],Lline[IMAGE_H],Mline[IMAGE_H];
extern uint8_t image_sobel[IMAGE_H][IMAGE_W];
extern uint8_t mid[IMAGE_H],left[IMAGE_H],right[IMAGE_H];   
//===================================================ȫ���з���ֵ��������===================================================
//===================================================ȫ���޷���ֵ��������===================================================
void Basic_Find_Boundry();
void scan();
void Find_Mid();
void zip();
void sobel();
void image_process();
#endif