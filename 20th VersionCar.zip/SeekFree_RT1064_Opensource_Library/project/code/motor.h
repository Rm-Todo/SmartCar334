#ifndef _MOTOR_H_
#define _MOTOR_H_
#include "zf_common_headfile.h"
//===================================================ȫ�ֱ�������===================================================
extern float z_speed;
extern float V1,V2,V3;
extern float max_speed;
extern float motor_ul_speed,motor_ur_speed,motor_md_speed;
extern uint8_t zebra_flag;
extern int PWM_L,PWM_M,PWM_R,target_speed;
extern uint8_t Zebra_crossing_stop_num;
extern bool time2_assigned;
extern bool time3_assigned;
//===================================================ȫ���з���ֵ��������===================================================
extern uint8_t Zebra_crossing_judgment();
//===================================================ȫ���޷���ֵ��������===================================================
void motor_control();
void Zebra(void);
void move_ctrl(int move_speed,int move_angle,int turn_angle,float z_p);
void set_motor_expect_speed(float L_Speed, float R_Speed, float M_Speed);
void motor_run(float target_speed);
void Stop(void);
void MOVE_ctrl(int move_speed,int move_angle,int turn_angle,float z_p);

#endif