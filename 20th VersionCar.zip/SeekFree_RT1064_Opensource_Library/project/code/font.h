#ifndef _FONT_H_
#define _FONT_H_
#include "zf_common_headfile.h"
void process_opflag(uint8_t opflag);
extern const uint8_t      mouse[4][16]; 
extern const uint8_t      keyboard[4][16]; 
extern const uint8_t 	  monitor[6][16];
extern const uint8_t 	  headphones[10][16];
extern const uint8_t      speaker[4][16];
extern const uint8_t      printer[6][16];
extern const uint8_t      phone[4][16];
extern const uint8_t 	  wrench[4][16];
extern const uint8_t      screwdriver[6][16]; 
extern const uint8_t      drill[6][16];
extern const uint8_t 	  pliers[4][16];
extern const uint8_t 	  multimeter[6][16]; 
extern const uint8_t 	  oscilloscope[6][16];
extern const uint8_t      soldering_iron[6][16];
extern const uint8_t 	  tape_measure[4][16];
//		ips200_show_chinese(0, 0, 16,mouse[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 20, 16,keyboard[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 40, 16,monitor[0], 3, RGB565_RED);//
//		ips200_show_chinese(0, 60, 16,headphones[0], 5, RGB565_RED);
//		ips200_show_chinese(0, 80, 16,speaker[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 100, 16,printer[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 120, 16,phone[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 140, 16,wrench[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 160, 16,screwdriver[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 180, 16,drill[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 200, 16,pliers[0], 2, RGB565_RED);
//		ips200_show_chinese(0, 220, 16,multimeter[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 240, 16,oscilloscope[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 260, 16,soldering_iron[0], 3, RGB565_RED);
//		ips200_show_chinese(0, 280, 16,tape_measure[0], 2, RGB565_RED);
#endif