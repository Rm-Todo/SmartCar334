#ifndef _TFT_SHOWN_H_
#define _TFT_SHOWN_H_
void show();
#endif