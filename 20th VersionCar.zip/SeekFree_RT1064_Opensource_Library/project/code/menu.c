/*
 * menu.c
 *
 *  Created on: 2024��9��26��
 */

#include "zf_common_headfile.h"
#include "menu.h"
#include <math.h>
int key[2],num,flag_key=0;

  DIPSwitchState getSwitchState()
{
    uint8_t state = (BOMA1 << 3) | (BOMA2 << 2) | (BOMA3 << 1) | BOMA4;
    return (state <= 0xF) ? (DIPSwitchState)state : STATE_ERROR;
}
//�ܿ�
void handle_state_0000()
{
	if(BOMA1==0 && BOMA2==0)		handle_state_0001();//���
	if(BOMA1==1 && BOMA2==0)		handle_state_0004();//����
	if(BOMA1==1 && BOMA2==1)		handle_state_0003();//����
	if(BOMA1==0 && BOMA2==1)		handle_state_0002();//����
}
//��������--���
void handle_state_0001()
{
	ips200_show_string(220, 0, "s");
    key[0]=gpio_get_level(B17);
    key[1]=gpio_get_level(B14);
    num=key[0]*1+key[1]*2;
    switch(num)
    {
        case 1:
        {
            flag_key=1;
            break;
        }
        case 2:
        {
            flag_key=2;
            break;
        }
        case 3:
        {
            flag_key=3;
            break;
        }
        default:break;
    }
    if(flag_key==1)
    {
		ips200_show_string(200, 20, "0.1P");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_servo.Kp+=0.1;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_servo.Kp-=0.1;
        }
    }
    if(flag_key==2)
    {
		ips200_show_string(200, 20, "0.2d");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_servo.Kd+=0.2;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_servo.Kd-=0.2;
        }
    }
    if(flag_key==3)
    {
		ips200_show_string(200, 20, "10tsp");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
			target_speed+=30;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
			target_speed-=30;
        }
    }
}
//����
void handle_state_0002()
{
	ips200_show_string(220, 0, "M");
	key[0]=gpio_get_level(B17);
    key[1]=gpio_get_level(B14);
    num=key[0]*1+key[1]*2;
    switch(num)
    {
        case 1:
        {
            flag_key=1;
            break;
        }
        case 2:
        {
            flag_key=2;
            break;
        }
        case 3:
        {
            flag_key=3;
            break;
        }
        default:break;
    }
    if(flag_key==1)
    {
		ips200_show_string(200, 20, "0.05i");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_M.Ki+=0.05;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_M.Ki-=0.05;
        }
    }
    if(flag_key==2)
    {
		ips200_show_string(200, 20, "0.2p");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_M.Kp+=0.2;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_M.Kp-=0.2;
        }
    }
    if(flag_key==3)
    {
		ips200_show_string(200, 20, "10tsp");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
			target_speed+=30;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
			target_speed-=30;
        }
    }	
}
//����
void handle_state_0003()
{
	ips200_show_string(220, 0, "R");
	key[0]=gpio_get_level(B17);
    key[1]=gpio_get_level(B14);
    num=key[0]*1+key[1]*2;
    switch(num)
    {
        case 1:
        {
            flag_key=1;
            break;
        }
        case 2:
        {
            flag_key=2;
            break;
        }
        case 3:
        {
            flag_key=3;
            break;
        }
        default:break;
    }
    if(flag_key==1)
    {
		ips200_show_string(200, 20, "0.1P");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_R.Kp+=0.1;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_R.Kp-=0.1;
        }
    }
    if(flag_key==2)
    {
		ips200_show_string(200, 20, "0.05i");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_R.Ki+=0.05;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_R.Ki-=0.05;
        }
    }
    if(flag_key==3)
    {
		ips200_show_string(200, 20, "10tsp");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
			target_speed+=30;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
			target_speed-=30;
        }
    }
}
//����
void handle_state_0004()
{
	ips200_show_string(220, 0, "L");
    key[0]=gpio_get_level(B17);
    key[1]=gpio_get_level(B14);
    num=key[0]*1+key[1]*2;
    switch(num)
    {
        case 1:
        {
            flag_key=1;
            break;
        }
        case 2:
        {
            flag_key=2;
            break;
        }
        case 3:
        {
            flag_key=3;
            break;
        }
        default:break;
    }
    if(flag_key==1)
    {
		ips200_show_string(200, 20, "0.1P");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_L.Kp+=0.1;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_L.Kp-=0.1;
        }
    }
    if(flag_key==2)
    {
		ips200_show_string(200, 20, "0.05i");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
            PID_L.Ki+=0.05;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
            PID_L.Ki-=0.05;
        }
    }
    if(flag_key==3)
    {
		ips200_show_string(200, 20, "10tsp");
        if(gpio_get_level(C31)==0)
        {
            while(gpio_get_level(C31)==0);
			target_speed+=30;
        }
        if(gpio_get_level(B10)==0)
        {
            while(gpio_get_level(B10)==0);
			target_speed-=30;
        }
    }
}
void handle_state_0005()
{

}
void handle_state_0006()
{

}
//��ʾ�һ�������
void handle_state_0007()
{

}
void handle_state_0008()
{

}
void handle_state_0009()
{

}
void handle_state_0010()
{

}
void handle_state_0011()
{

}
void handle_state_0012()
{

}
void handle_state_0013()
{
 
}
void handle_state_0014()
{

}
//��ʾ��ɫ�����Ϣ
void handle_state_0015()
{
   
}
void processLoveLetter(DIPSwitchState state)
{
    switch(state) {
        case STATE_0000:
            handle_state_0000();
            printf("%d\n", state);  // ʮ��������
            break;
        case STATE_0001:
            handle_state_0001();
           printf("%d\n", state);  // ��һ��
            break;
        case STATE_0010:
            handle_state_0002();
            printf("%d\n", state);  // �ڶ���
            break;
        case STATE_0011:
            handle_state_0003();
            printf("%d\n", state);  // ������
            break;
        case STATE_0100:
            handle_state_0004();
            printf("%d\n", state);  // ������
            break;
        case STATE_0101:
            handle_state_0005();
            printf("%d\n", state);  // ������
            break;
        case STATE_0110:
            handle_state_0006();
            printf("%d\n", state);  // ������
            break;
        case STATE_0111:
            handle_state_0007();
            printf("%d\n", state);  // ������
            break;
        case STATE_1000:
            handle_state_0008();
            printf("%d\n", state);  //�ڰ���
            break;
        case STATE_1001:
            handle_state_0009();
            printf("%d\n", state);  // ���ٶ�kp
            break;
        case STATE_1010:
            handle_state_0010();
            printf("%d\n", state);  // ���ٶ�kd
            break;
        case STATE_1011:
            handle_state_0011();
            printf("%d\n", state);  // �Ƕ�kp
            break;
        case STATE_1100:
            handle_state_0012();
            printf("%d\n", state);  // �Ƕ�ki
            break;
        case STATE_1101:
            handle_state_0013();
            printf("%d\n", state);  // �Ƕ�kd
            break;
        case STATE_1110:
            handle_state_0014();
            printf("%d\n", state);  // λ��kp
            break;
        case STATE_1111:
            handle_state_0015();
            printf("%d\n", state);  // λ��kd
            break;
        default:
            printf("%d\n", state);  // ����
    }
} 

  