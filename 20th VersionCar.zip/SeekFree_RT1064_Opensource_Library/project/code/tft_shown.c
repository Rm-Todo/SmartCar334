#include "zf_common_headfile.h"
#include "tft_shown.h" 


void show()
{
	ips200_show_gray_image(0, 0, image_sobel[0], 94, 60, 94, 60, 0);
	for(int i=59;i>0;i--)
	{
			ips200_draw_line(mid[i], i, mid[i], i+1,RGB565_BLUE);
			ips200_draw_line(mid[i]+1, i, mid[i]+1, i+1,RGB565_BLUE);
			ips200_draw_line(right[i], i, right[i], i+1,RGB565_BLUE);
			ips200_draw_line(left[i], i, left[i], i+1,RGB565_BLUE);
	}
//			ips200_draw_line(10, 25, 100, 25,RGB565_GREEN);//25��
			ips200_draw_line(10, 35, 100, 35,RGB565_GREEN);//35��
			ips200_draw_line(10, 55, 100, 55,RGB565_GREEN);//55��

//			ips200_draw_line(10, 5, 10, 55,RGB565_GREEN);//20��
//			ips200_draw_line(47, 5, 47, 55,RGB565_GREEN);//47��
//			ips200_draw_line(80, 5, 80, 55,RGB565_GREEN);//80��
//===================================================ȫ�ֱ��������ʾ===================================================	
		ips200_show_string(95, 0, "err");//ͼ��ƫ��ֵ
		ips200_show_float(150, 0, error2,3,2);
		ips200_show_string(95,20,"ERR");//����ֵ
		ips200_show_int(150, 20, error, 4);
		ips200_show_string(95, 40, "gyr");
		ips200_show_float(150, 40, my_angle.Gyro.z,3,2);
		ips200_show_string(95, 60, "GYR");
		ips200_show_float(150, 60, my_angle.Yaw,3,2);
		ips200_show_string(0, 60, "S");
		ips200_show_int(55, 60, area, 4);
		ips200_show_string(0, 80, "tsp");
		ips200_show_int(55, 80, target_speed, 4);
//===================================================�ֲ����������ʾ===================================================			
		ips200_show_string(35, 100, "svr");
		ips200_show_string(90, 100, "L");
		ips200_show_string(140, 100, "M");
		ips200_show_string(183, 100, "R");
	
		ips200_show_string(0, 120, "kp");
		ips200_show_float(35, 120, PID_servo.Kp,3,2);
		ips200_show_float(90, 120, PID_L.Kp,3,2);
		ips200_show_float(140, 120, PID_M.Kp,3,2);
		ips200_show_float(183, 120, PID_R.Kp,3,2);
		ips200_show_string(0, 140, "ki");
		ips200_show_float(90, 140, PID_L.Ki,3,2);
		ips200_show_float(140, 140, PID_M.Ki,3,2);
		ips200_show_float(183, 140, PID_R.Ki,3,2);
		ips200_show_string(0, 160, "kd");
		ips200_show_float(35, 160, PID_servo.Kd,3,2);
		ips200_show_string(0, 180, "V");
		ips200_show_int(90, 180, speedL, 4);
		ips200_show_int(140, 180, speedM, 4);
		ips200_show_int(183, 180, speedR, 4);
		ips200_show_string(0, 200, "pwm");
		ips200_show_int(90, 200, PWM_L, 4);
		ips200_show_int(140, 200, PWM_M, 4);
		ips200_show_int(183, 200, PWM_R, 4);
		ips200_show_string(0, 220, "len");
		ips200_show_int(90, 220, distanceL, 4);
		ips200_show_int(140, 220, distanceM, 4);
		ips200_show_int(183, 220, distanceR, 4);
		ips200_show_string(0, 240, "flg");
		ips200_show_int(90, 240, left_round_flag, 4);
		ips200_show_int(183, 240, right_round_flag, 4);
		ips200_show_string(0, 260, "k");
		ips200_show_float(90, 260, leftslope,3,2);
		ips200_show_float(183, 260, rightslope,3,2);
		ips200_show_string(0, 280, "lsm");
		ips200_show_int(90, 280, left_loss_sum, 4);
		ips200_show_int(140, 280, err_loss_sum, 4);
		ips200_show_int(183, 280, right_loss_sum, 4);
		ips200_show_string(0, 300, "con");
		ips200_show_int(90, 300, left_countinue, 4);
		ips200_show_int(183, 300, right_countinue, 4);		
}