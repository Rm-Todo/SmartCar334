#ifndef _SERVO_H_
#define _SERVO_H_
#include "zf_common_headfile.h"
//===================================================ȫ�ֱ�������===================================================
extern int error_x;
extern int error_y;
extern int X_P,X_D,Y_P,Y_D;
extern int cube_flag;
extern float speed_x;
extern float speed_y;
extern float temp;
extern int alpha;
extern float car_direction;
extern uint16_t target_area;
extern bool is_target_tracking;  
extern int last_error_x, last_error_y;
extern int move_speed, move_angle;
//===================================================ȫ���з���ֵ��������===================================================

//===================================================ȫ���޷���ֵ��������===================================================
void tracking_control(int target_x, int target_y, int current_x, int current_y);
void right_tracking_control(int target_x, int target_y, int current_x, int current_y);
void calculate_movement(int error_x, int error_y, int* move_speed, int* move_angle); 
void push_out();
void come_back();
void park();
void straight_left_move1();
void straight_left_move2();
void straight_right_move1();
void straight_right_move2();
bool read_light_sensor();



#endif